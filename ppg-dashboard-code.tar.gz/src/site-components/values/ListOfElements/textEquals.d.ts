import type { ReactNode } from 'react';
export declare const textEquals: (config: {
    text: string;
    caseSensitive: boolean;
}) => (value: ReactNode | undefined) => boolean;
